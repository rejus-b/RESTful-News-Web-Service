from django.apps import AppConfig


class CwkappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cwkapp'
